/* GoogleTagManagerJS */
(function(){
  // GoogleTagManagerJS Bundle
  var pushToDataLayer = true;

  function onReady(a,b,c){b=document,c='addEventListener'; b[c] ? b[c]('DOMContentLoaded',a) : window.attachEvent('onload',a)}

  var triggerPushToDataLayer = function() {
    window.dataLayer = window.dataLayer || [];

    
  }

  if (document.readyState === "complete"
    || document.readyState === "loaded"
    || document.readyState === "interactive") {
    triggerPushToDataLayer();
  } else {
    onReady(triggerPushToDataLayer);
  }

}());

